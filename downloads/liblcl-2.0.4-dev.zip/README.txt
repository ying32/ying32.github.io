﻿所有Windows下的二进制都采用upx 3.9.6进行压缩。

1、liblcl.dll于Windows 10下编译。
2、liblcl.so于Linux Mint 19下编译。
3、liblcl.dylib于macOS High Sierra 10.13.6下编译。


All binary under Windows and Linux are compressed by upx 3.9.6.  

1, liblcl.dll compiled under Windows 10.
2, liblcl.so compiled under Linux Mint 19.
3, liblcl.dylib compiled under macOS High Sierra 10.13.6.

--------------------

注：COPYING.modifiedLGPL.txt为所用到的LCL标准组件和所用到的第三方组件（TRichMemo、TATGuage）授权协议。

Note: COPYING.modifiedLGPL.txt is the LCL standard component used and the third-party component (TRichMemo, TATGuage) used license.